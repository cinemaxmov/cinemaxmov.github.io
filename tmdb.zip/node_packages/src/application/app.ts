/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

import php, {express} from "../zend/engine"
import "../zend/lib"
import "../zend/library"
import "../zend/constant"
import "../zend/db"
import "../zend/theme"
import "../zend/template"
import "../zend/worker"
import "../plugin/TMDB"

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

var {ln, ln_r} = php.constant
var {lib} = php

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

var app = new php.worker (php.express)
app.start (async function (request: any, response: any, next: any) {
	await libraries (request, response, next)
	if (request.error ["found"] === "host") return response (php.error.HOST_NOT_FOUND, php.error.found)
	if (request.error ["forbidden"] === "agent") return response (php.error.VISITOR_AGENT, php.error.forbidden)
	else return next ()
	})

async function libraries (request: any, response: any, next: any) {
	if (request.app.host in app.host) {
		if (request.organic ()) {
			if (request.app.theme = {id: app.host [request.app.host].theme.id})
			if (app.host [request.app.host].theme.version) {} else request.app.theme.version = app.theme [request.app.theme.id].version.last ()
			if (request.library = new library (request, response, next)) return php.promise (function (resolve: any, reject: any) {
				var then : any = function () {
					then.queue.push (true)
					if (then.queue.length > 1) resolve ()
					}
				then.queue = []
				lib.timeout (async function () {
					request.config = app.config
					request.db = new php.db (request.app.host)
					request.library.output ()
					request.library.seo ()
					request.theme = new php.theme (request.app.theme, request.output.theme_url)
					await request.theme.fetch ()
					resolve ()
					})
				})
			}
		else return php.promise (function (resolve: any, reject: any) {
			request.error ["forbidden"] = "agent"
			resolve ()
			})
		}
	else return php.promise (function (resolve: any, reject: any) {
		request.error ["found"] = "host"
		resolve ()
		})
	}

function theme_r (request: any, response: any, next: any) {
	//
	}

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get ("/", async function (request: any, response: any, next: any) {
	theme_r (request, response, next)
	request.output ["page:is"] = "index"
	var html = []
	if (request.organic ()) {
		var data = await request.TMDB.movie.popular ({page: request.url.query.get ("page")})
		html.push (`
			<style>
			.video-card-test-container { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; }
			.video-card-test-single { display: flex; }
			.video-card-test-single-thumbnail-container { border-radius: 8px; overflow: hidden; }
			</style>
			`)
		html.push (`<div class="video-card-test-container">`)
		for (var i in data.list) {
			var single = data.list [i]
			html.push (`<div class="video-card-test-single">
			<!--div>Title : ${data.list [i].title}</div-->
			<a href="${single.permalink_watch}" class="video-card-test-single-thumbnail-container"><img width="180" height="270" src="${data.list [i].poster}"></a>
			</div>`)
			}
		html.push (`<div class="video-card-test-single">
			<a href="#" class="video-card-test-single-thumbnail-container relative" style="color: rgb(var(--color))">
			<div class="flex align-item justify-item x v absolute bold font-size:large">MOVIE</div>
			<img width="180" height="270" src="/static/w500.jpg">
			</a>
			</div>`)
		html.push ("</div>")
		}
	/*
	// var layout = request.theme.layout ("index").set ({}, 5)
	// var body = request.theme.layout ("base").set ({body: layout}, 2)
	var menu_list = request.theme.component ("menu:anchor").set ({}, 8)
	var layout = request.theme.layout ("index").set ({}, 5)
	// var layout = request.theme.layout ("index").set ({"location menu:list": [menu_list, menu_list, menu_list]}, 5)
	var body = request.theme.layout ("base").set ({body: layout}, 2)
	body = php.render (body, {"theme menu:list": [menu_list]})
	*/
	var layout = request.theme.layout ("index").set ({}, 5)
	var body = request.theme.layout ("base").set ({body: layout}, 2)
	body = php.render (body, {"data": html.join ("\n")})
	return response.output (body)
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get (app.route.page ["privacy"], function (request: any, response: any, next: any) {
	return response ("privacy")
	})

app.get (app.route.page ["privacy-policy"], function (request: any, response: any, next: any) {
	var layout = request.theme.layout ("page").set ({}, 5)
	var body = request.theme.layout ("base").set ({body: layout}, 2)
	body = php.render (body, {"data": `
<div id="block-info" class="flex flex:row">
Your privacy is very important to us. This page explains how we collect, use, and protect your personal information when you use our site, Cinema Movie.
<br><br>
<strong>1. Information We Collect</strong>
Your IP address
Device and browser type
Pages you access and time of visit
Content preferences such as movie genre or country of origin
We do not collect personal information such as your name, email address, or other sensitive data directly, unless you contact us through the contact form.
<br><br>
<strong>2. Use of Information</strong>
The information we collect is used for:
<br><br>
- Improving user experience<br>
- Showing relevant movie content<br>
- Detecting and preventing suspicious activity<br>
- Internal analytics and feature development<br>
<br><br>
<strong>3. Cookies</strong>
Our site uses cookies to store user preferences and site usage statistics. You can disable cookies through your browser settings at any time.
<br><br>
<strong>4. Third Parties</strong>
We may use third-party services such as Google Analytics, advertising, or CDNs to improve our services. These third parties may also use cookies or similar trackers.
<br><br>
<strong>5. Links to Other Sites</strong>
Our site may contain links to third-party sites. We are not responsible for the content or privacy policies of those sites.
<br><br>
<strong>6. Data Security</strong>
We use our best efforts to protect your information, but no system is completely secure. You use this site with awareness of these risks.
<br><br>
<strong>7. Consent</strong>
By using this site, you agree to our privacy policy.
<br><br>
<strong>8. Policy Changes</strong>
We may update this policy at any time. Changes will be displayed on this page with the latest revision date.
<br><br>
<strong>9. Contact</strong>
If you have any questions regarding this policy, please contact us at info@cinemamovie.online
</div>
		`})
	return response.output (body)
	})

app.get (app.route.page ["privacy-policy:content"], function (request: any, response: any, next: any) {
	return response ("privacy policy content")
	})

app.get (app.route.page ["FAQ"], function (request: any, response: any, next: any) {
	var layout = request.theme.layout ("page").set ({}, 5)
	var body = request.theme.layout ("base").set ({body: layout}, 2)
	body = php.render (body, {"data": `
		<div id="block-info" class="flex flex-row">
<h2><strong>Frequently Asked Questions</strong></h2>
<strong>What is Cinemamovie.online?</strong>
Cinemamovie.online, abbreviated as Cinema Movie, is a platform that provides information about movies and series from various sources on the internet. We do not store or host any content on our servers, but instead display links from third parties.
<ul>
 	<li><strong>Is watching on this site legal?</strong>
Legality depends on your country's jurisdiction. We only display publicly available links. Use this service wisely and in accordance with applicable laws in your region.</li>
 	<li><strong>Is this site free?</strong>
Yes, it is completely free and requires no registration. We do not charge for accessing movie information or third-party links.</li>
 	<li><strong>Why are there so many ads?</strong>
Advertisements help support the site's operations, keeping it online and free for all users. However, we strive to place ads in a way that does not interfere with your experience.</li>
 	<li><strong>The movie I'm looking for isn't available, what should I do?</strong>
Please use the search feature or check back in a few days. We regularly update our film and series database.</li>
 	<li><strong>What happens if there is copyright infringement?</strong>
We respect intellectual property rights. If you are a copyright owner and find an infringement, please see our DMCA Notice page and submit a formal notification.</li>
 	<li><strong>Can I request a movie or series?</strong>
We currently don't accept manual movie requests, but we will consider this feature in the future.</li>
 	<li><strong>I'm experiencing an error while playing a movie. What's the solution?</strong>
Try changing players or refreshing the page. If the problem persists, the third-party video source is likely down.</li>
 	<li><strong>Is this site safe to visit?</strong>
We don't store user data and don't require a login. Use a browser with an active ad blocker for a safer experience.</li>
</ul>
		</div>
		`})
	return response.output (body)
	})

app.get (app.route.page ["DMCA"], function (request: any, response: any, next: any) {
	var layout = request.theme.layout ("page").set ({}, 5)
	var body = request.theme.layout ("base").set ({body: layout}, 2)
	body = php.render (body, {"data": `
<div id="block-info" class="flex flex:row">
<h2><strong>Notice</strong></h2>
We respect the intellectual property rights of others and expect you to do the same. In accordance with the Digital Millennium Copyright Act (DMCA), we will respond to legitimate takedown requests for alleged copyright infringement occurring on this site.
<br><br>
<strong>1. Third-Party Links</strong>
Cinemamovie.online does not store any film, video, or media files on our servers. All content displayed is sourced from third-party sites, such as public streaming services, that are openly available on the internet.
<br><br>
<strong>2. Submit a Takedown Request</strong>
If you are a copyright owner or represent a rights owner and believe that an infringement has occurred, you may submit a DMCA notice to us by including the following information:
<br><br>
- Your complete identity and contact information.<br>
- A description of the copyrighted work being infringed.<br>
- The specific URL containing the infringing material.<br>
- A statement that you have a good faith belief that use of the material is not authorized by the copyright owner.<br>
- A statement under penalty of perjury that the information in this notice is accurate and that you are the rights owner or authorized to act on behalf of the - copyright owner.<br>
- Your physical or electronic signature.<br>
- Please send your request to the following email address: dmca[at]Cinemamovie.online
<br><br>
<strong>3. Our Action</strong>
Upon receiving a valid notification, we will process it within 48–72 business hours. We may remove or disable access to the relevant content while we investigate the claim.
<br><br>
<strong>4. Additional Notes</strong>
We are not a video host and do not control the content of third-party sites. If you wish to have the content removed completely, we recommend that you also contact the platform where the content originated.
</div>
		`})
	return response.output (body)
	})

app.get (app.route.page ["disclaimer"], function (request: any, response: any, next: any) {
	var layout = request.theme.layout ("page").set ({}, 5)
	var body = request.theme.layout ("base").set ({body: layout}, 2)
	body = php.render (body, {"data": `
<div id="block-info" class="flex flex:row">
Cinemamovie.online only provides information about movie links available on the internet. We do not store video files on our own servers. All content belongs to the original providers.
</div>
		`})
	return response.output (body)
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get (app.route.archive, function (request: any, response: any, next: any) {
	return response ("archive index")
	})

app.get (app.route ["archive:year"], function (request: any, response: any, next: any) {
	return response ("archive year")
	})

app.get (app.route ["archive:month"], function (request: any, response: any, next: any) {
	return response ("archive month")
	})

app.get (app.route ["archive:day"], function (request: any, response: any, next: any) {
	return response ("archive day")
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get (app.route.movie, async function (request: any, response: any, next: any) {
	return response ("movie index")
	})

app.get (app.route ["movie:watch"], async function (request: any, response: any, next: any) {
	request.output ["page:is"] = "index"
	var html : any = []
	var movie_id = php.plugin.TMDB.to_id (request.url.path)
	var data = await request.TMDB.movie.single ({id: movie_id})
	request.output ["title"] = request.output ["og:title"] = [request.db.select ("config").get ("site:name"), data.title].join (" | ")
	request.output ["meta:description"] = data.overview
	request.output ["og:description"] = data.overview
	// https://cinemamovie.net/tmdb.php?tmdb_id=1311031
	var vidsrc_url = "https://cinemamovie.net/tmdb.php?tmdb_id=" + movie_id
	var vidsrc_link : any = await fetch (vidsrc_url)
	vidsrc_link = await vidsrc_link.text ()
	// return response (`<iframe id="player-vidsrc" src="${vidsrc_link}" frameborder="0" allowfullscreen width="100%" height="100%" scrolling="no"></iframe>`)
	html.push (`<iframe id="player-vidsrc" src="${vidsrc_link}" frameborder="0" allowfullscreen width="100%" height="100%" scrolling="no"></iframe>`)
	var layout = request.theme.layout ("index").set ({}, 5)
	var body = request.theme.layout ("base").set ({body: layout}, 2)
	body = php.render (body, {"data": html.join ("\n")})
	return response.output (body)
	})

app.get (app.route ["movie:discover"], async function (request: any, response: any, next: any) {
	return response ("movie discover")
	})

app.get (app.route ["movie:popular"], async function (request: any, response: any, next: any) {
	var html = []
	if (request.organic ()) {
		var data = await request.TMDB.movie.popular ({page: request.url.query.get ("page")})
		html.push ('<div style="display: flex">')
		for (var i in data.list) {
			html.push (`<div>
			<div>Title : ${data.list [i].title}</div>
			<div><img height="150" src="${data.list [i].poster}"></div>
			</div>`)
			}
		html.push ("</div>")
		}
	return response (html.join ("")	)
	})

app.get (app.route ["movie:now_playing"], async function (request: any, response: any, next: any) {
	return response ("movie now_playing")
	})

app.get (app.route ["movie:top_rated"], async function (request: any, response: any, next: any) {
	return response ("movie top_rated")
	})

app.get (app.route ["movie:up_coming"], async function (request: any, response: any, next: any) {
	return response ("movie up_coming")
	})

app.get (app.route ["movie:single"], async function (request: any, response: any, next: any) {
	return response ("movie single")
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get (app.route.movie.path, async function (request: any, response: any, next: any) {
	return next ()
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get (app.route.path, function (request: any, response: any, next: any) {
	console.log ("path : ", request.url.path)
	console.log ("path : ", request.url.param ("path"))
	return next ()
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.catch (function (request: any, response: any, next: any) {
	return response ("not found", 404)
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

var library : any = class {
	request: any
	response: any
	next: any
	constructor (request: any, response: any, next: any) {
		this.request = request
		this.response = response
		this.next = next
		this.plugin ()
		}
	plugin () {
		this.request.TMDB = new php.plugin.TMDB (app.config ["TMDB:api"], this.request)
		}
	async output () {
		if  (app.config.deployment === "local") {
			this.request.output.asset_url = this.request.base_url + app.route ["$"].asset_uri
			this.request.output.static_url = this.request.base_url + app.route ["$"].static_uri
			this.request.output.theme_url = this.request.base_url + app.route ["$"].theme_uri
			}
		if  (app.config.deployment === "live") {
			this.request.output.asset_url = app.config ["asset:url"] + app.route ["$"].asset_uri
			this.request.output.static_url = app.config ["static:url"] + app.route ["$"].static_uri
			this.request.output.theme_url = app.config ["theme:url"] + app.route ["$"].theme_uri
			}
		this.request.output.latest = app.config.latest
		this.request.output.theme_id = this.request.app.theme.id
		this.request.output.theme_version = this.request.app.theme.version
		console.log (this.request.app.theme)
		this.request.output.title = this.request.db.select ("config").get ("site:title")
		this.request.output ["meta:description"] = this.request.db.select ("config").get ("meta:description")
		this.request.output ["meta:keyword"] = this.request.db.select ("config").get ("meta:keyword").join (", ")
		}
	async seo () {
		this.request.output ["og:site-name"] = ""
		this.request.output ["og:title"] = this.request.db.select ("config").get ("site:title")
		this.request.output ["og:description"] = this.request.db.select ("config").get ("meta:description")
		this.request.output ["og:url"] = this.request.canonical_url
		this.request.output ["og:type"] = "website"
		var date_atom = new Date ().toISOString ()
		this.request.output ["article:published_time"] = date_atom
		this.request.output ["article:modified_time"] = date_atom
		}
	}

library.meta = function () {}
library.meta.single = function (request: any, response: any, next: any) {}

library.route = function () {}
library.route.popular = async function popular_list (request: any, response: any, next: any) {
   var html = []
   if (request.organic ()) {
	   var data = await request.TMDB.movie.popular ({page: request.url.query.get ("page")})
	   html.push ('<div style="display: flex">')
	   for (var i in data.list) {
		   html.push (`<div>
		   <div>Title : ${data.list [i].title}</div>
		   <div><img height="150" src="${data.list [i].poster}"></div>
		   </div>`)
		   }
	   html.push ("</div>")
	   }
   return response (php.html ["output"] (html.join ("")))
   }

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

export default app.export ()

/**
 * the end
 *
 * xxx://xxx.xxx.xxx/xxx
 */