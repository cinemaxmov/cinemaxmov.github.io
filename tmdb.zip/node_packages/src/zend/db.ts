import php from "../zend/engine";

import db_local_config from "../db/127.0.0.1/config.json";
import db_local_test from "../db/127.0.0.1/test.json";

php.db = class {
	data: any = {}
	__: any = {config: {}}
	constructor (host: string) {
		this.data = php.db.data [host];
		this.extract ();
		}
	extract () {
		for (var i in this.data.config) {
			if ("id" in this.data.config [i]) this.__ ["config"] [this.data.config [i].key] = this.data.config [i].value;
			}
		}
	select (table: string) {
		return new php.db.select (this, table);
		}
	}

php.db.select = class {
	db: any;
	table: string;
	constructor (db: any, table: string) {
		this.db = db;
		this.table = table;
		}
	get (key: string) {
		return this.db.__ [this.table][key];
		}
	}

php.db.data = {}
php.db.data ["127.0.0.1"] = {config: db_local_config, test: db_local_test}
php.db.data ["cinemamovie.online"] = {config: db_local_config, test: db_local_test}