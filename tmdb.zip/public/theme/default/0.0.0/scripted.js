$ (document).ready (function () {
	body_css ()
	})

$ (document).click (function (event) {
	//
	})

$ (window).on ("resize", function () {
	body_css ()
	})