import php from "../zend/engine";

php.theme = class {
	id: string;
	version: string;
	prefix: string;
	io: any;
	constructor (theme: any, prefix: string) {
		this.id = theme.id;
		this.version = theme.version;
		this.prefix = prefix;
		this.io = new php.theme.io (this);
		}
	layout (id: string) { return new php.theme.layout (this, id); }
	component (id: string) { return new php.theme.component (this, id); }
	async fetch () {
		var theme : any = await this.io.fetch ();
		for (var i in theme.layout) this.io.layout [i] = theme.layout [i].ln;
		for (var i in theme.component) this.io.component [i] = theme.component [i].ln;
		return new Promise (function (resolve, reject) { resolve (true); });
		}
	}

php.theme.io = class {
	theme: any;
	layout: any = {}
	component: any = {}
	constructor (theme: any) {
		this.theme = theme;
		}
	fetch () {
		var prefix = this.theme.prefix;
		var theme_id = this.theme.id;
		var theme_version = this.theme.version;
		return new Promise (async function (resolve, reject) {
			var id : string = "";
			var tmp : any = {layout: {}, component: {}}
			var layout : any = await fetch ([prefix, theme_id, theme_version, "layout"].join ("/"));
			layout = await layout.text ();
			layout = layout.split ("\n");
			for (var i in layout) {
				if (layout [i]) {
					if (layout [i].startsWith (`<template id`)) {
						id = str_before (`"`, str_after (`<template id="`, layout [i]))
						tmp.layout [id] = {ln: []}
						continue;
						}
					else if (layout [i] === `</template>`) continue;
					else tmp.layout [id].ln.push (layout [i]);
					}
				}
			var component : any = await fetch ([prefix, theme_id, theme_version, "component"].join ("/"));
			component = await component.text ();
			component = component.split ("\n");
			for (var i in component) {
				if (component [i].startsWith (`<template id`)) {
					id = str_before (`"`, str_after (`<template id="`, component [i]));
					tmp.component [id] = {ln: []}
					continue;
					}
				else if (component [i] === `</template>`) continue;
				else if (tmp.component [id]) tmp.component [id].ln.push (component [i]);
				}
			resolve ({layout: tmp.layout, component: tmp.component});
			});
		}
	}

php.theme.layout = class {
	theme: any;
	id: string;
	constructor (theme: any, id: string) {
		this.theme = theme;
		this.id = id;
		}
	set (variable: any = {}, tab: number = 0) {
		var markup = this.theme.io.layout [this.id];
		if (markup) return php.render (markup, variable, tab);
		else return "";
		}
	}

php.theme.component = class {
	theme: any;
	id: string;
	constructor (theme: any, id: string) {
		this.theme = theme;
		this.id = id;
		}
	set (variable: any = {}, tab: number = 0) {
		var markup = this.theme.io.component [this.id];
		if (markup) return php.render (markup, variable, tab);
		else return "";
		}
	array (data: any = [], tab: number = 0) {
		var template = this.theme.io.component [this.id];
		var markup = [];
		if (template) {
			for (var i in data) {
				markup.push (php.render (template, data [i], tab));
				}
			return markup.join ("\n");
			}
		else return "";
		}
	}

function str_after (search: string, input: string) {
	var pos = input.indexOf (search);
	if (pos !== undefined) return input.substr (pos + search.length);
	else return "";
	}

function str_before (search: string, input: string) {
	return input.split (search) [0];
	}

php.theme.json = php.thema;