import php from "../zend/engine";

php.constant = {
	ln: "\n",
	ln_r: "\r\n",
	}