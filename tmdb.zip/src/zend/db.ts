import php from "../zend/engine";

import db_local_config from "../db/127.0.0.1/table-config.json";
import db_local_page from "../db/127.0.0.1/table-page.json";
import db_local_test from "../db/127.0.0.1/test.json";

php.db = class {
	table: any = {}
	__: any = {config: {}}
	constructor (host: string) {
		this.table = php.db.table [host];
		this.extract ();
		}
	extract () {
		for (var i in this.table.config) {
			if ("id" in this.table.config [i]) this.__ ["config"] [this.table.config [i].key] = this.table.config [i].value;
			}
		}
	select (table: string) {
		return new php.db.select (this, table);
		}
	}

php.db.select = class {
	db: any;
	table: string;
	constructor (db: any, table: string) {
		this.db = db;
		this.table = table;
		}
	array (where: any) {
		var data: any = [];
		var table = this.db.table [this.table];
		if (where) {
			for (var i in table) {
				for (var x in where) {
					if (table [i][x] === where [x]) data.push (table [i]);
					}
				}
			return data;
			}
		else return table;
		}
	get (key: string) {
		return this.db.__ [this.table][key];
		}
	}

php.db.table = {}
php.db.table ["127.0.0.1"] = {config: db_local_config, page: db_local_page, test: db_local_test}
php.db.table ["cinemamovie.online"] = php.db.table ["127.0.0.1"];