/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

import php, {express} from "../zend/engine"
import "../zend/lib"
import "../zend/library"
import "../zend/constant"
import "../zend/db"
import "../zend/theme"
import "../zend/template"
import "../zend/worker"
import "../plugin/TMDB"

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

var {ln, ln_r} = php.constant
var {lib} = php
const zero = 0
const one = 1

const THEME_LAYOUT_TAB = 5
const THEME_BODY_TAB = 2

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

var app = new php.worker (php.express)
app.start (async function (request: any, response: any, next: any) {
	await libraries (request, response, next)
	if (request.error ["found"] === "host") return response (php.error.HOST_NOT_FOUND, php.error.found)
	if (request.error ["forbidden"] === "agent") return response (php.error.VISITOR_AGENT, php.error.forbidden)
	else return next ()
	})

async function libraries (request: any, response: any, next: any) {
	if (request.app.host in app.host) {
		if (request.organic ()) {
			if (request.app.theme = {id: app.host [request.app.host].theme.id})
			if (app.host [request.app.host].theme.version) {} else request.app.theme.version = app.theme [request.app.theme.id].version.last ()
			if (request.library = new library (request, response, next)) return php.promise (function (resolve: any, reject: any) {
				var then : any = function () {
					then.queue.push (true)
					if (then.queue.length > 1) resolve ()
					}
				then.queue = []
				lib.timeout (async function () {
					request.config = app.config
					request.db = new php.db (request.app.host)
					request.library.output ()
					request.library.seo ()
					request.theme = new php.theme (request.app.theme, request.output.theme_url)
					await request.theme.fetch ()
					resolve ()
					})
				})
			}
		else return php.promise (function (resolve: any, reject: any) {
			request.error ["forbidden"] = "agent"
			resolve ()
			})
		}
	else return php.promise (function (resolve: any, reject: any) {
		request.error ["found"] = "host"
		resolve ()
		})
	}

function theme_r (request: any, response: any, next: any) {
	//
	}

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get ("/", async function (request: any, response: any, next: any) {
	var component: any = {}
	component.header_test = request.theme.component ("header:test").set ({})
	component.section_trending_title = request.theme.component ("section-title:test").set ({title: "Trending", icon: "local_fire_department"})
	component.section_movie_title = request.theme.component ("section-title:test").set ({title: "Movies", icon: "local_fire_department"})
	component.section_tv_title = request.theme.component ("section-title:test").set ({title: "TV Shows", icon: "local_fire_department"})
	component.all_trending = []
	var all_trending = await request.TMDB.all.trending ({page: request.url.query.get ("page")})
	for (var i in all_trending.list) component.all_trending.push (request.theme.component ("video-card:test").set ({"title": all_trending.list [i].title, "release_date": all_trending.list [i].release_date, "release_date_string": all_trending.list [i].release_date_string, "permalink": all_trending.list [i].permalink, "permalink:watch": all_trending.list [i].permalink_watch, "poster": all_trending.list [i].poster}, 2))
	component.all_trending = component.all_trending.join (ln)
	component.all_trending = request.theme.component ("video-card:test container").set ({slot: component.all_trending})
	component.movie_popular = []
	var movie_popular = await request.TMDB.movie.popular ({page: request.url.query.get ("page")})
	for (var i in movie_popular.list) component.movie_popular.push (request.theme.component ("video-card:test").set ({"title": movie_popular.list [i].title, "release_date": movie_popular.list [i].release_date, "release_date_string": movie_popular.list [i].release_date_string, "permalink": movie_popular.list [i].permalink, "permalink:watch": movie_popular.list [i].permalink_watch, "poster": movie_popular.list [i].poster}, 2))
	component.movie_popular = component.movie_popular.join (ln)
	component.movie_popular = request.theme.component ("video-card:test container").set ({slot: component.movie_popular})
	component.tv_popular = []
	var tv_popular = await request.TMDB.tv.popular ({page: request.url.query.get ("page")})
	for (var i in tv_popular.list) component.tv_popular.push (request.theme.component ("video-card:test").set ({"title": tv_popular.list [i].title, "release_date": tv_popular.list [i].release_date, "release_date_string": tv_popular.list [i].release_date_string, "permalink": tv_popular.list [i].permalink, "permalink:watch": tv_popular.list [i].permalink_watch, "poster": tv_popular.list [i].poster}, 2))
	component.tv_popular = component.tv_popular.join (ln)
	component.tv_popular = request.theme.component ("video-card:test container").set ({slot: component.tv_popular})
	var layout = request.theme.layout ("index").set ({
		"theme:location main": [
			component.header_test,
			component.section_trending_title, component.all_trending,
			component.section_movie_title, component.movie_popular,
			component.section_tv_title, component.tv_popular,
			],
		}, 5)
	var body = response.render.vue (layout)
	return response.output (body)
	/*
	theme_r (request, response, next)
	request.output ["page:is"] = "index"
	var html = []
	if (request.organic ()) {
		var data = await request.TMDB.movie.popular ({page: request.url.query.get ("page")})
		html.push (`<div class="video-card-test-container">`)
		for (var i in data.list) {
			var single = data.list [i]
			html.push (`<div class="video-card-test-single">
			<!--div>Title : ${data.list [i].title}</div-->
			<a href="${single.permalink_watch}" class="video-card-test-single-thumbnail-container"><img width="180" height="270" src="${data.list [i].poster}"></a>
			</div>`)
			}
		html.push (`<div class="video-card-test-single">
			<a href="#" class="video-card-test-single-thumbnail-container relative" style="color: rgb(var(--color))">
			<div class="flex align-item justify-item x v absolute bold font-size:large">MOVIE</div>
			<img width="180" height="270" src="/static/w500.jpg">
			</a>
			</div>`)
		html.push ("</div>")
		}
	var layout = request.theme.layout ("index").set ({}, 5)
	var body = request.theme.layout ("base").set ({body: layout}, 2)
	body = php.render (body, {"data": html.join ("\n")})
	return response.output (body)
	*/
	/*
	// var layout = request.theme.layout ("index").set ({}, 5)
	// var body = request.theme.layout ("base").set ({body: layout}, 2)
	var menu_list = request.theme.component ("menu:anchor").set ({}, 8)
	var layout = request.theme.layout ("index").set ({}, 5)
	// var layout = request.theme.layout ("index").set ({"location menu:list": [menu_list, menu_list, menu_list]}, 5)
	var body = request.theme.layout ("base").set ({body: layout}, 2)
	body = php.render (body, {"theme menu:list": [menu_list]})
	*/
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get (app.route.page ["privacy"], function (request: any, response: any, next: any) {
	return response ("privacy")
	})

app.get (app.route.page ["privacy-policy"], function (request: any, response: any, next: any) {
	var fp
	if (fp = request.db.select ("page").array ({path: app.route.page ["privacy-policy"]}) [zero]) {
		var layout = request.theme.layout (fp.theme.layout).set ({}, THEME_LAYOUT_TAB)
		var body = request.theme.layout ("vue").set ({body: layout}, THEME_BODY_TAB)
		body = php.render (body, {"theme:location main": fp.content})
		return response.output (body)
		}
	else return next ()
	})

app.get (app.route.page ["privacy-policy:content"], function (request: any, response: any, next: any) {
	return response ("privacy policy content")
	})

app.get (app.route.page ["FAQ"], function (request: any, response: any, next: any) {
	var fp
	if (fp = request.db.select ("page").array ({path: app.route.page ["FAQ"]}) [zero]) {
		var layout = request.theme.layout (fp.theme.layout).set ({}, THEME_LAYOUT_TAB)
		var body = request.theme.layout ("vue").set ({body: layout}, THEME_BODY_TAB)
		body = php.render (body, {"theme:location main": fp.content})
		return response.output (body)
		}
	else return next ()
	})

app.get (app.route.page ["DMCA"], function (request: any, response: any, next: any) {
	var fp
	if (fp = request.db.select ("page").array ({path: app.route.page ["DMCA"]}) [zero]) {
		var layout = request.theme.layout (fp.theme.layout).set ({}, THEME_LAYOUT_TAB)
		var body = request.theme.layout ("vue").set ({body: layout}, THEME_BODY_TAB)
		body = php.render (body, {"theme:location main": fp.content})
		return response.output (body)
		}
	else return next ()
	})

app.get (app.route.page ["disclaimer"], function (request: any, response: any, next: any) {
	var fp
	if (fp = request.db.select ("page").array ({path: app.route.page ["disclaimer"]}) [zero]) {
		var layout = request.theme.layout (fp.theme.layout).set ({}, THEME_LAYOUT_TAB)
		var body = request.theme.layout ("vue").set ({body: layout}, THEME_BODY_TAB)
		body = php.render (body, {"theme:location main": fp.content})
		return response.output (body)
		}
	else return next ()
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get (app.route.archive, function (request: any, response: any, next: any) {
	return response ("archive index")
	})

app.get (app.route ["archive:year"], function (request: any, response: any, next: any) {
	return response ("archive year")
	})

app.get (app.route ["archive:month"], function (request: any, response: any, next: any) {
	return response ("archive month")
	})

app.get (app.route ["archive:day"], function (request: any, response: any, next: any) {
	return response ("archive day")
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get (app.route ["movie"], async function (request: any, response: any, next: any) {
	var component: any = {}
	component.header_test = request.theme.component ("header:test").set ({})
	component.section_trending_title = request.theme.component ("section-title:test").set ({title: "Trending", icon: "local_fire_department"})
	component.section_popular_title = request.theme.component ("section-title:test").set ({title: "Popular", icon: "local_fire_department"})
	component.section_up_coming_title = request.theme.component ("section-title:test").set ({title: "Up Coming", icon: "local_fire_department"})
	component.section_top_rated_title = request.theme.component ("section-title:test").set ({title: "Top Rated", icon: "local_fire_department"})
	if (component.movie_trending = []) {
		var movie_trending = await request.TMDB.movie.trending ({page: request.url.query.get ("page")})
		for (var i in movie_trending.list) component.movie_trending.push (request.theme.component ("video-card:test").set ({"title": movie_trending.list [i].title, "release_date": movie_trending.list [i].release_date, "release_date_string": movie_trending.list [i].release_date_string, "permalink": movie_trending.list [i].permalink, "permalink:watch": movie_trending.list [i].permalink_watch, "poster": movie_trending.list [i].poster}, 2))
		component.movie_trending = component.movie_trending.join (ln)
		component.movie_trending = request.theme.component ("video-card:test container").set ({slot: component.movie_trending})
		}
	if (component.movie_popular = []) {
		var movie_popular = await request.TMDB.movie.popular ({page: request.url.query.get ("page")})
		for (var i in movie_popular.list) component.movie_popular.push (request.theme.component ("video-card:test").set ({"title": movie_popular.list [i].title, "release_date": movie_popular.list [i].release_date, "release_date_string": movie_popular.list [i].release_date_string, "permalink": movie_popular.list [i].permalink, "permalink:watch": movie_popular.list [i].permalink_watch, "poster": movie_popular.list [i].poster}, 2))
		component.movie_popular = component.movie_popular.join (ln)
		component.movie_popular = request.theme.component ("video-card:test container").set ({slot: component.movie_popular})
		}
	if (component.movie_up_coming = []) {
		var movie_up_coming = await request.TMDB.movie.up_coming ({page: request.url.query.get ("page")})
		for (var i in movie_up_coming.list) component.movie_up_coming.push (request.theme.component ("video-card:test").set ({"title": movie_up_coming.list [i].title, "release_date": movie_up_coming.list [i].release_date, "release_date_string": movie_up_coming.list [i].release_date_string, "permalink": movie_up_coming.list [i].permalink, "permalink:watch": movie_up_coming.list [i].permalink_watch, "poster": movie_up_coming.list [i].poster}, 2))
		component.movie_up_coming = component.movie_up_coming.join (ln)
		component.movie_up_coming = request.theme.component ("video-card:test container").set ({slot: component.movie_up_coming})
		}
	if (component.movie_top_rated = []) {
		var movie_top_rated = await request.TMDB.movie.top_rated ({page: request.url.query.get ("page")})
		for (var i in movie_top_rated.list) component.movie_top_rated.push (request.theme.component ("video-card:test").set ({"title": movie_top_rated.list [i].title, "release_date": movie_top_rated.list [i].release_date, "release_date_string": movie_top_rated.list [i].release_date_string, "permalink": movie_top_rated.list [i].permalink, "permalink:watch": movie_top_rated.list [i].permalink_watch, "poster": movie_top_rated.list [i].poster}, 2))
		component.movie_top_rated = component.movie_top_rated.join (ln)
		component.movie_top_rated = request.theme.component ("video-card:test container").set ({slot: component.movie_top_rated})
		}
	var layout = request.theme.layout ("index").set ({
		"theme:location main": [
			component.section_trending_title, component.movie_trending,
			component.section_popular_title, component.movie_popular,
			component.section_up_coming_title, component.movie_up_coming,
			component.section_top_rated_title, component.movie_top_rated,
			],
		}, 5)
	var body = response.render.vue (layout)
	return response.output (body)
	})

app.get (app.route ["movie:watch"], async function (request: any, response: any, next: any) {
	request.output ["page:is"] = "index"
	var html : any = []
	var movie_id = php.plugin.TMDB.to_id (request.url.path)
	var data = await request.TMDB.movie.single ({id: movie_id})
	request.output ["title"] = request.output ["og:title"] = [request.db.select ("config").get ("site:name"), data.title].join (" | ")
	request.output ["meta:description"] = data.overview
	request.output ["og:description"] = data.overview
	// https://cinemamovie.net/tmdb.php?tmdb_id=1311031
	var vidsrc_url = "https://cinemamovie.net/tmdb.php?tmdb_id=" + movie_id
	var vidsrc_link : any = await fetch (vidsrc_url)
	vidsrc_link = await vidsrc_link.text ()
	// return response (`<iframe id="player-vidsrc" src="${vidsrc_link}" frameborder="0" allowfullscreen width="100%" height="100%" scrolling="no"></iframe>`)
	html.push (`<iframe id="player-vidsrc" src="${vidsrc_link}" frameborder="0" allowfullscreen width="100%" height="100%" scrolling="no"></iframe>`)
	var layout = request.theme.layout ("index").set ({
		"theme:location main": html.join (ln),
		}, 5)
	var body = response.render.vue (layout)
	return response.output (body)
	})

app.get (app.route ["movie:discover"], async function (request: any, response: any, next: any) {
	return response ("movie discover")
	})

app.get (app.route ["movie:popular"], async function (request: any, response: any, next: any) {
	var html = []
	if (request.organic ()) {
		var data = await request.TMDB.movie.popular ({page: request.url.query.get ("page")})
		html.push ('<div style="display: flex">')
		for (var i in data.list) {
			html.push (`<div>
			<div>Title : ${data.list [i].title}</div>
			<div><img height="150" src="${data.list [i].poster}"></div>
			</div>`)
			}
		html.push ("</div>")
		}
	return response (html.join ("")	)
	})

app.get (app.route ["movie:now_playing"], async function (request: any, response: any, next: any) {
	return response ("movie now_playing")
	})

app.get (app.route ["movie:top_rated"], async function (request: any, response: any, next: any) {
	return response ("movie top_rated")
	})

app.get (app.route ["movie:up_coming"], async function (request: any, response: any, next: any) {
	return response ("movie up_coming")
	})

app.get (app.route ["movie:single"], async function (request: any, response: any, next: any) {
	return response ("movie single")
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get (app.route ["tv"], async function (request: any, response: any, next: any) {
	var component: any = {}
	component.header_test = request.theme.component ("header:test").set ({})
	component.section_trending_title = request.theme.component ("section-title:test").set ({title: "Trending", icon: "local_fire_department"})
	component.section_popular_title = request.theme.component ("section-title:test").set ({title: "Popular", icon: "local_fire_department"})
	component.section_airing_today_title = request.theme.component ("section-title:test").set ({title: "Airing Today", icon: "local_fire_department"})
	component.section_on_the_air_title = request.theme.component ("section-title:test").set ({title: "On the Air", icon: "local_fire_department"})
	component.section_top_rated_title = request.theme.component ("section-title:test").set ({title: "Top Rated", icon: "local_fire_department"})
	if (component.tv_trending = []) {
		var tv_trending = await request.TMDB.tv.trending ({page: request.url.query.get ("page")})
		for (var i in tv_trending.list) component.tv_trending.push (request.theme.component ("video-card:test").set ({"title": tv_trending.list [i].title, "release_date": tv_trending.list [i].release_date, "release_date_string": tv_trending.list [i].release_date_string, "permalink": tv_trending.list [i].permalink, "permalink:watch": tv_trending.list [i].permalink_watch, "poster": tv_trending.list [i].poster}, 2))
		component.tv_trending = component.tv_trending.join (ln)
		component.tv_trending = request.theme.component ("video-card:test container").set ({slot: component.tv_trending})
		}
	if (component.tv_popular = []) {
		var tv_popular = await request.TMDB.tv.popular ({page: request.url.query.get ("page")})
		for (var i in tv_popular.list) component.tv_popular.push (request.theme.component ("video-card:test").set ({"title": tv_popular.list [i].title, "release_date": tv_popular.list [i].release_date, "release_date_string": tv_popular.list [i].release_date_string, "permalink": tv_popular.list [i].permalink, "permalink:watch": tv_popular.list [i].permalink_watch, "poster": tv_popular.list [i].poster}, 2))
		component.tv_popular = component.tv_popular.join (ln)
		component.tv_popular = request.theme.component ("video-card:test container").set ({slot: component.tv_popular})
		}
	if (component.tv_airing_today = []) {
		var tv_airing_today = await request.TMDB.tv.airing_today ({page: request.url.query.get ("page")})
		for (var i in tv_airing_today.list) component.tv_airing_today.push (request.theme.component ("video-card:test").set ({"title": tv_airing_today.list [i].title, "release_date": tv_airing_today.list [i].release_date, "release_date_string": tv_airing_today.list [i].release_date_string, "permalink": tv_airing_today.list [i].permalink, "permalink:watch": tv_airing_today.list [i].permalink_watch, "poster": tv_airing_today.list [i].poster}, 2))
		component.tv_airing_today = component.tv_airing_today.join (ln)
		component.tv_airing_today = request.theme.component ("video-card:test container").set ({slot: component.tv_airing_today})
		}
	if (component.tv_on_the_air = []) {
		var tv_on_the_air = await request.TMDB.tv.on_the_air ({page: request.url.query.get ("page")})
		for (var i in tv_on_the_air.list) component.tv_on_the_air.push (request.theme.component ("video-card:test").set ({"title": tv_on_the_air.list [i].title, "release_date": tv_on_the_air.list [i].release_date, "release_date_string": tv_on_the_air.list [i].release_date_string, "permalink": tv_on_the_air.list [i].permalink, "permalink:watch": tv_on_the_air.list [i].permalink_watch, "poster": tv_on_the_air.list [i].poster}, 2))
		component.tv_on_the_air = component.tv_on_the_air.join (ln)
		component.tv_on_the_air = request.theme.component ("video-card:test container").set ({slot: component.tv_on_the_air})
		}
	if (component.tv_top_rated = []) {
		var tv_top_rated = await request.TMDB.tv.top_rated ({page: request.url.query.get ("page")})
		for (var i in tv_top_rated.list) component.tv_top_rated.push (request.theme.component ("video-card:test").set ({"title": tv_top_rated.list [i].title, "release_date": tv_top_rated.list [i].release_date, "release_date_string": tv_top_rated.list [i].release_date_string, "permalink": tv_top_rated.list [i].permalink, "permalink:watch": tv_top_rated.list [i].permalink_watch, "poster": tv_top_rated.list [i].poster}, 2))
		component.tv_top_rated = component.tv_top_rated.join (ln)
		component.tv_top_rated = request.theme.component ("video-card:test container").set ({slot: component.tv_top_rated})
		}
	var layout = request.theme.layout ("index").set ({
		"theme:location main": [
			component.section_trending_title, component.tv_trending,
			component.section_popular_title, component.tv_popular,
			component.section_airing_today_title, component.tv_airing_today,
			component.section_on_the_air_title, component.tv_on_the_air,
			component.section_top_rated_title, component.tv_top_rated,
			],
		}, 5)
	var body = response.render.vue (layout)
	return response.output (body)
	})

app.get (app.route ["tv:watch"], async function (request: any, response: any, next: any) {
	var season = request.url.param ("season")
	var episode = request.url.param ("episode")
	request.output ["page:is"] = "index"
	var html : any = []
	var tv_id = php.plugin.TMDB.to_tv_id (request.url.path)
	var data = await request.TMDB.tv.single ({id: tv_id})
	request.output ["title"] = request.output ["og:title"] = [request.db.select ("config").get ("site:name"), (data.title || data.name)].join (" | ")
	request.output ["meta:description"] = data.overview
	request.output ["og:description"] = data.overview
	var vidsrc_url = "https://cinemamovie.net/wp-content/themes/muvipro/lib.php?tmdb_id={id}&season={season}&episode={episode}".split ("{id}").join (tv_id).split ("{season}").join (season).split ("{episode}").join (episode)
	var vidsrc_link : any = await fetch (vidsrc_url)
	vidsrc_link = await vidsrc_link.text ()
	html.push (`<iframe id="player-vidsrc" src="${vidsrc_link}" frameborder="0" allowfullscreen width="100%" height="100%" scrolling="no"></iframe>`)
	var layout = request.theme.layout ("index").set ({
		"theme:location main": html.join (ln),
		}, 5)
	var body = response.render.vue (layout)
	return response.output (body)
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.get (app.route.path, function (request: any, response: any, next: any) {
	console.log ("path : ", request.url.path)
	console.log ("path : ", request.url.param ("path"))
	return next ()
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

app.catch (function (request: any, response: any, next: any) {
	return response ("not found", 404)
	})

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

var library : any = class {
	request: any
	response: any
	next: any
	constructor (request: any, response: any, next: any) {
		this.request = request
		this.response = response
		this.next = next
		this.plugin ()
		}
	plugin () {
		this.request.TMDB = new php.plugin.TMDB (app.config ["TMDB:api"], this.request)
		}
	async output () {
		if  (app.config.deployment === "local") {
			this.request.output.asset_url = this.request.base_url + app.route ["$"].asset_uri
			this.request.output.static_url = this.request.base_url + app.route ["$"].static_uri
			this.request.output.theme_url = this.request.base_url + app.route ["$"].theme_uri
			}
		if  (app.config.deployment === "live") {
			this.request.output.asset_url = app.config ["asset:url"] + app.route ["$"].asset_uri
			this.request.output.static_url = app.config ["static:url"] + app.route ["$"].static_uri
			this.request.output.theme_url = app.config ["theme:url"] + app.route ["$"].theme_uri
			}
		this.request.output.latest = app.config.latest
		this.request.output.theme_id = this.request.app.theme.id
		this.request.output.theme_version = this.request.app.theme.version
		this.request.output.title = this.request.db.select ("config").get ("site:title")
		this.request.output ["meta:description"] = this.request.db.select ("config").get ("meta:description")
		this.request.output ["meta:keyword"] = this.request.db.select ("config").get ("meta:keyword").join (", ")
		}
	async seo () {
		this.request.output ["og:site-name"] = this.request.db.select ("config").get ("site:name")
		this.request.output ["og:title"] = this.request.db.select ("config").get ("site:title")
		this.request.output ["og:description"] = this.request.db.select ("config").get ("meta:description")
		this.request.output ["og:url"] = this.request.canonical_url
		this.request.output ["og:image"] = ""
		this.request.output ["og:type"] = "website"
		var date_atom = new Date ().toISOString ()
		this.request.output ["article:published_time"] = date_atom
		this.request.output ["article:modified_time"] = date_atom
		}
	}

library.meta = function () {}
library.meta.single = function (request: any, response: any, next: any) {}

library.route = function () {}
library.route.popular = async function popular_list (request: any, response: any, next: any) {
   var html = []
   if (request.organic ()) {
	   var data = await request.TMDB.movie.popular ({page: request.url.query.get ("page")})
	   html.push ('<div style="display: flex">')
	   for (var i in data.list) {
		   html.push (`<div>
		   <div>Title : ${data.list [i].title}</div>
		   <div><img height="150" src="${data.list [i].poster}"></div>
		   </div>`)
		   }
	   html.push ("</div>")
	   }
   return response (php.html ["output"] (html.join ("")))
   }

/**
 * xxx
 *
 * title
 * description
 * sub description
 *
 * xxx://xxx.xxx.xxx/xxx
 */

export default app.export ()

/**
 * the end
 *
 * xxx://xxx.xxx.xxx/xxx
 */